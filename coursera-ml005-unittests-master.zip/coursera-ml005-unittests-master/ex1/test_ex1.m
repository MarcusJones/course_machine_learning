%!test test_sanity()

%!test test_warmup()

%!test test_computeCost()

%!test test_gradientDescent

%!test test_featureNormalize

%!test test_computeCostMulti

%!test test_gradientDescentMulti

%!test test_normalEqn
