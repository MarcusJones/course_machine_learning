function test_sanity ()
  % make sure tests are running correctly
  assert(1,1);
endfunction
