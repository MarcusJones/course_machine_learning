%!test test_sanity()

%!test test_sigmoid()

%!test test_costfunction_minimal()

%!test test_costfunction_nontrivial()

%!test test_costfunction_forums()

%!test test_predict()

%!test test_costfunction_reg_minimal()

%!test test_costFunctionReg()
